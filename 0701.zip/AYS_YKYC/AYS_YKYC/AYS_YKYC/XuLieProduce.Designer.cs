﻿namespace H07_YKYC
{
    partial class XuLieProduce
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.panel_S1 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.radioButton_LocalMiYue_Refresh = new System.Windows.Forms.RadioButton();
            this.radioButton_LocalMiYue_Binary = new System.Windows.Forms.RadioButton();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.radioButton_LocalSuanFa_Refresh = new System.Windows.Forms.RadioButton();
            this.radioButton_LocalSuanFa_Binary = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.radioButton_LocalMingMi_ON = new System.Windows.Forms.RadioButton();
            this.radioButton_LocalMingMi_OFF = new System.Windows.Forms.RadioButton();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.groupBox5.SuspendLayout();
            this.panel_S1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button1.Font = new System.Drawing.Font("宋体", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button1.Location = new System.Drawing.Point(489, 297);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(66, 32);
            this.button1.TabIndex = 18;
            this.button1.Text = "确定";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.panel_S1);
            this.groupBox5.Font = new System.Drawing.Font("宋体", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox5.Location = new System.Drawing.Point(21, 27);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(534, 76);
            this.groupBox5.TabIndex = 17;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "发送指令";
            // 
            // panel_S1
            // 
            this.panel_S1.BackColor = System.Drawing.Color.LightSteelBlue;
            this.panel_S1.Controls.Add(this.label5);
            this.panel_S1.Controls.Add(this.label1);
            this.panel_S1.Controls.Add(this.label4);
            this.panel_S1.Controls.Add(this.textBox1);
            this.panel_S1.Controls.Add(this.label3);
            this.panel_S1.Controls.Add(this.textBox2);
            this.panel_S1.Controls.Add(this.label2);
            this.panel_S1.Controls.Add(this.textBox3);
            this.panel_S1.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.panel_S1.Location = new System.Drawing.Point(18, 23);
            this.panel_S1.Name = "panel_S1";
            this.panel_S1.Size = new System.Drawing.Size(507, 37);
            this.panel_S1.TabIndex = 13;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(73, 11);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(11, 12);
            this.label5.TabIndex = 14;
            this.label5.Text = "K";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 13;
            this.label1.Text = "指令代号";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(395, 14);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(17, 12);
            this.label4.TabIndex = 13;
            this.label4.Text = "MS";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(89, 7);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(45, 21);
            this.textBox1.TabIndex = 14;
            this.textBox1.Text = "2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(285, 14);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 12);
            this.label3.TabIndex = 13;
            this.label3.Text = "发送间隔";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(211, 7);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(53, 21);
            this.textBox2.TabIndex = 14;
            this.textBox2.Text = "10";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(152, 14);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 13;
            this.label2.Text = "发送次数";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(343, 7);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(45, 21);
            this.textBox3.TabIndex = 14;
            this.textBox3.Text = "1000";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.radioButton_LocalMiYue_Refresh);
            this.groupBox4.Controls.Add(this.radioButton_LocalMiYue_Binary);
            this.groupBox4.Font = new System.Drawing.Font("宋体", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox4.Location = new System.Drawing.Point(201, 66);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(159, 87);
            this.groupBox4.TabIndex = 16;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "本机密钥状态";
            // 
            // radioButton_LocalMiYue_Refresh
            // 
            this.radioButton_LocalMiYue_Refresh.BackColor = System.Drawing.Color.LightSteelBlue;
            this.radioButton_LocalMiYue_Refresh.Location = new System.Drawing.Point(21, 49);
            this.radioButton_LocalMiYue_Refresh.Name = "radioButton_LocalMiYue_Refresh";
            this.radioButton_LocalMiYue_Refresh.Size = new System.Drawing.Size(120, 24);
            this.radioButton_LocalMiYue_Refresh.TabIndex = 13;
            this.radioButton_LocalMiYue_Refresh.TabStop = true;
            this.radioButton_LocalMiYue_Refresh.Text = "更新密钥";
            this.radioButton_LocalMiYue_Refresh.UseVisualStyleBackColor = false;
            // 
            // radioButton_LocalMiYue_Binary
            // 
            this.radioButton_LocalMiYue_Binary.BackColor = System.Drawing.Color.LightSteelBlue;
            this.radioButton_LocalMiYue_Binary.Checked = true;
            this.radioButton_LocalMiYue_Binary.Location = new System.Drawing.Point(21, 19);
            this.radioButton_LocalMiYue_Binary.Name = "radioButton_LocalMiYue_Binary";
            this.radioButton_LocalMiYue_Binary.Size = new System.Drawing.Size(120, 24);
            this.radioButton_LocalMiYue_Binary.TabIndex = 13;
            this.radioButton_LocalMiYue_Binary.TabStop = true;
            this.radioButton_LocalMiYue_Binary.Text = "初始密钥";
            this.radioButton_LocalMiYue_Binary.UseVisualStyleBackColor = false;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.radioButton_LocalSuanFa_Refresh);
            this.groupBox3.Controls.Add(this.radioButton_LocalSuanFa_Binary);
            this.groupBox3.Font = new System.Drawing.Font("宋体", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox3.Location = new System.Drawing.Point(366, 66);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(159, 87);
            this.groupBox3.TabIndex = 15;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "算法状态";
            // 
            // radioButton_LocalSuanFa_Refresh
            // 
            this.radioButton_LocalSuanFa_Refresh.BackColor = System.Drawing.Color.LightSteelBlue;
            this.radioButton_LocalSuanFa_Refresh.Location = new System.Drawing.Point(21, 50);
            this.radioButton_LocalSuanFa_Refresh.Name = "radioButton_LocalSuanFa_Refresh";
            this.radioButton_LocalSuanFa_Refresh.Size = new System.Drawing.Size(120, 24);
            this.radioButton_LocalSuanFa_Refresh.TabIndex = 13;
            this.radioButton_LocalSuanFa_Refresh.TabStop = true;
            this.radioButton_LocalSuanFa_Refresh.Text = "更新算法参数";
            this.radioButton_LocalSuanFa_Refresh.UseVisualStyleBackColor = false;
            // 
            // radioButton_LocalSuanFa_Binary
            // 
            this.radioButton_LocalSuanFa_Binary.BackColor = System.Drawing.Color.LightSteelBlue;
            this.radioButton_LocalSuanFa_Binary.Checked = true;
            this.radioButton_LocalSuanFa_Binary.Location = new System.Drawing.Point(21, 20);
            this.radioButton_LocalSuanFa_Binary.Name = "radioButton_LocalSuanFa_Binary";
            this.radioButton_LocalSuanFa_Binary.Size = new System.Drawing.Size(120, 24);
            this.radioButton_LocalSuanFa_Binary.TabIndex = 13;
            this.radioButton_LocalSuanFa_Binary.TabStop = true;
            this.radioButton_LocalSuanFa_Binary.Text = "初始算法参数";
            this.radioButton_LocalSuanFa_Binary.UseVisualStyleBackColor = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.radioButton_LocalMingMi_ON);
            this.groupBox2.Controls.Add(this.radioButton_LocalMingMi_OFF);
            this.groupBox2.Font = new System.Drawing.Font("宋体", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox2.Location = new System.Drawing.Point(18, 66);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(177, 87);
            this.groupBox2.TabIndex = 14;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "本机明密状态";
            // 
            // radioButton_LocalMingMi_ON
            // 
            this.radioButton_LocalMingMi_ON.BackColor = System.Drawing.Color.LightSteelBlue;
            this.radioButton_LocalMingMi_ON.Location = new System.Drawing.Point(18, 50);
            this.radioButton_LocalMingMi_ON.Name = "radioButton_LocalMingMi_ON";
            this.radioButton_LocalMingMi_ON.Size = new System.Drawing.Size(120, 24);
            this.radioButton_LocalMingMi_ON.TabIndex = 13;
            this.radioButton_LocalMingMi_ON.TabStop = true;
            this.radioButton_LocalMingMi_ON.Text = "本机密态";
            this.radioButton_LocalMingMi_ON.UseVisualStyleBackColor = false;
            // 
            // radioButton_LocalMingMi_OFF
            // 
            this.radioButton_LocalMingMi_OFF.BackColor = System.Drawing.Color.LightSteelBlue;
            this.radioButton_LocalMingMi_OFF.Checked = true;
            this.radioButton_LocalMingMi_OFF.Location = new System.Drawing.Point(18, 20);
            this.radioButton_LocalMingMi_OFF.Name = "radioButton_LocalMingMi_OFF";
            this.radioButton_LocalMingMi_OFF.Size = new System.Drawing.Size(120, 24);
            this.radioButton_LocalMingMi_OFF.TabIndex = 13;
            this.radioButton_LocalMingMi_OFF.TabStop = true;
            this.radioButton_LocalMingMi_OFF.Text = "本机明态";
            this.radioButton_LocalMingMi_OFF.UseVisualStyleBackColor = false;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.panel2);
            this.groupBox6.Controls.Add(this.groupBox2);
            this.groupBox6.Controls.Add(this.groupBox3);
            this.groupBox6.Controls.Add(this.groupBox4);
            this.groupBox6.Font = new System.Drawing.Font("宋体", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox6.Location = new System.Drawing.Point(21, 109);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(534, 166);
            this.groupBox6.TabIndex = 19;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "发送数据";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.LightSteelBlue;
            this.panel2.Controls.Add(this.label12);
            this.panel2.Controls.Add(this.textBox9);
            this.panel2.Controls.Add(this.textBox10);
            this.panel2.Controls.Add(this.button2);
            this.panel2.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.panel2.Location = new System.Drawing.Point(18, 23);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(507, 37);
            this.panel2.TabIndex = 13;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(3, 12);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(53, 12);
            this.label12.TabIndex = 13;
            this.label12.Text = "文件代号";
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(58, 7);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(45, 21);
            this.textBox9.TabIndex = 14;
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(197, 7);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(292, 21);
            this.textBox10.TabIndex = 14;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(116, 5);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 15;
            this.button2.Text = "选择文件";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(21, 335);
            this.textBox4.Multiline = true;
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(534, 225);
            this.textBox4.TabIndex = 20;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(19, 320);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 12);
            this.label6.TabIndex = 21;
            this.label6.Text = "生成序列";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(563, 49);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(47, 37);
            this.button3.TabIndex = 14;
            this.button3.Text = "ADD";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(561, 132);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(47, 37);
            this.button4.TabIndex = 22;
            this.button4.Text = "ADD";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // XuLieProduce
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(627, 578);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.groupBox5);
            this.Name = "XuLieProduce";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "XuLieProduce";
            this.groupBox5.ResumeLayout(false);
            this.panel_S1.ResumeLayout(false);
            this.panel_S1.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Panel panel_S1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.RadioButton radioButton_LocalMiYue_Refresh;
        private System.Windows.Forms.RadioButton radioButton_LocalMiYue_Binary;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.RadioButton radioButton_LocalSuanFa_Refresh;
        private System.Windows.Forms.RadioButton radioButton_LocalSuanFa_Binary;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton radioButton_LocalMingMi_ON;
        private System.Windows.Forms.RadioButton radioButton_LocalMingMi_OFF;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
    }
}